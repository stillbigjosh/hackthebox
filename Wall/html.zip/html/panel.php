<?php


echo "Just a test for php file !";

?>
